data/ directory will appear automatically in emscripten web builds.

  * The .rgb file represents uncompressed RGB video data.
  * the the screenmap.json is the screenmap for "strip1"