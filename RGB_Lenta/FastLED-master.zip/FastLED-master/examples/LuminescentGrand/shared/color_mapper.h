

#ifndef COLOR_MAPPER_H_
#define COLOR_MAPPER_H_

#include "./color.h"

const ColorHSV SelectColor(int midi_note, float brightness, int color_selector_val);

#endif // COLOR_MAPPER_H_
